import { Link, Outlet } from "react-router-dom";
import {
  GoABAppFooter,
  GoABAppHeader, GoABButton, GoABCircularProgress, GoABDropdown, GoABDropdownItem, GoABFormItem,
  GoABMicrositeHeader,
  GoABOneColumnLayout,
  GoABSideMenu,
  GoABSideMenuGroup,
} from "@abgov/react-components";
import "@abgov/style";
import { useEffect, useState } from "react";

export function App() {
  const [fullScreenProgress, setFullScreenProgress] = useState(0);
  const [fullScreenMessage, setFullScreenMessage] = useState("Progress starting");
  const [fullScreenProgressVisible, setFullScreenProgressVisible] = useState(false);

  function showFullScreenProgress() {
    setFullScreenProgressVisible(true);
  }

  useEffect(() => {
    if (fullScreenProgressVisible) {
      setInterval(() => {
        if (fullScreenProgress >= 100) {
          setFullScreenProgress(0);
        } else {
          setFullScreenProgress(fullScreenProgress + 10);
        }
        setFullScreenMessage("Progress at " + fullScreenProgress);
      }, 1000);
    }
  }, [fullScreenProgressVisible])

  return (
    <GoABOneColumnLayout>
      <section slot="header">
        <GoABMicrositeHeader type="alpha" version="UAT" />
        <GoABAppHeader url="/" heading="Design System">
          <a href="/login">Sign in</a>
        </GoABAppHeader>
      </section>
      <div style={{ display: "flex" }}>
        <section style={{ flex: "0 0 250px" }}>
          <GoABSideMenu>
            <GoABSideMenuGroup heading="Components">
              <Link to="/">Nothing here</Link>

              {/* Add links here */}
            </GoABSideMenuGroup>

            {/* Add links here */}
          </GoABSideMenu>
        </section>
        <section>
          <Outlet />
          {/*<GoABFormItem label="Basic dropdown">*/}
          {/*  <GoABDropdown onChange={(e) => console.log(e)} name="item" value="" filterable={true}>*/}
          {/*    <GoABDropdownItem value="red" label="Red"></GoABDropdownItem>*/}
          {/*    <GoABDropdownItem value="green" label="Green"></GoABDropdownItem>*/}
          {/*    <GoABDropdownItem value="blue" label="Blue"></GoABDropdownItem>*/}
          {/*  </GoABDropdown>*/}
          {/*</GoABFormItem>*/}
          <GoABButton onClick={showFullScreenProgress}>Show fullscreen</GoABButton>
          <GoABCircularProgress variant="fullscreen"
                                progress={fullScreenProgress}
                                message={fullScreenMessage}
                                visible={fullScreenProgressVisible}
                                ></GoABCircularProgress>
        </section>
      </div>
      <section slot="footer">
        <GoABAppFooter />
      </section>
    </GoABOneColumnLayout>
  );
}

export default App;
